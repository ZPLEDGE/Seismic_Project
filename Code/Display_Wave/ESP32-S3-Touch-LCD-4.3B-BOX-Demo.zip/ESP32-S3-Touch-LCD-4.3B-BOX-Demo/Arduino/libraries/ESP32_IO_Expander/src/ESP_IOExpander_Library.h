/*
 * SPDX-FileCopyrightText: 2023 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * This file is just to keep the compatibility with the old version of the library. Please use the file `esp_io_expander.hpp` instead.
 */

#pragma once

#warning "This file is deprecated. Please use the file `esp_io_expander.hpp` instead."

#include "esp_io_expander.hpp"
